<?php 
    include '../db_connect.php';
    $id = $_GET['id'];

    $qDellBarang="delete from barang where barang_id='$id'";
    $myConn->query($qDellBarang);
    //mysqli_query($koneksi, "delete from barang where barang_id='$id'");

    $qDellBarangMasuk="delete from barang_masuk where bm_id_barang='$id'";
    $myConn->query($qDellBarangMasuk);
    //mysqli_query($koneksi, "delete from barang_masuk where bm_id_barang='$id'");
    $qDellBarangKeluar="delete from barang_masuk where bm_id_barang='$id'";
    $myConn->query($qDellBarangKeluar);
    //mysqli_query($koneksi, "delete from barang_keluar where bk_id_barang='$id'");

header("location:barang.php");
