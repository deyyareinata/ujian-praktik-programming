<?php 
    include "db_connect.php";
    $id = $_GET['id'];

    $qDellKategori="delete from kategori where id='$id'";
    $myConn->query($qDellKategori);

header("location:kategori.php");