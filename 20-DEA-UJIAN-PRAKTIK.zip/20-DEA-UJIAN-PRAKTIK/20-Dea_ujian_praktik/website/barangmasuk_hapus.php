<?php 
include 'db_connect.php';
$id = $_GET['id'];

$qDellBarangMasuk="delete from barangmasuk where id='$id'";
$myConn->query($qDellBarangMasuk);

header("location:barangmasuk.php");