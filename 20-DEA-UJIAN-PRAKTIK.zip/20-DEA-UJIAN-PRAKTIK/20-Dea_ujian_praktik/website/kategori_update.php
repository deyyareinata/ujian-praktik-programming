<?php 
include '../db_connect.php';
//$id  = $_POST['id'];
$kategori  = $_POST['kategori'];
$keterangan = $_POST['keterangan'];

$qUpdateKategori = "update kategori
                    kategori='$kategori', 
                    keterangan='$keterangan',
                   ";
//jalankan query
$myConn->query($qUpdateKategori);                    

//mysqli_query($koneksi, "update barang set barang_nama='$nama', barang_spesifikasi='$spesifikasi', barang_lokasi='$lokasi', barang_kondisi='$kondisi', barang_jumlah='$jumlah', barang_sumber_dana='$sumber_dana', barang_keterangan='$keterangan', barang_jenis='$jenis' where barang_id='$id'");
header("location:kategori.php");