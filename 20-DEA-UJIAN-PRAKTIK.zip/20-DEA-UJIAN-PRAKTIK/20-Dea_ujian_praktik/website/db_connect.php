<?php 

//$koneksi = mysqli_connect("localhost", "root", "" ,"12sija_inventaris");

//code untuk ke database server
//data yang disiapkan 

$dbHost = "localhost";
$dbUser = "admin_inventory";
$dbPass = "123";
$dbName = "db_inventory";

//mysqli OOP 
//koneksi php ke mysql server menggunakan method mysqli()
//nama object $myConn

$myConn = new mysqli("$dbHost", "$dbUser", "$dbPass", "$dbName");

//print "error: " .$myConn->error;
//print "<br>";
//print "error code:" .$    myConn->connect_errno;

//menghentikan program
//die("stop");


//artinya database server yang diakses terletak pada server yang sama - pengguna mengakses langsung di pc yang diinstall 

?>

