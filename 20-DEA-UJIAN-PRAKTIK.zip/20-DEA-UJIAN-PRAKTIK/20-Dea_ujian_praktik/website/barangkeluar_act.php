<?php 
include 'db_connect.php';
$tgl_keluar = $_POST['tgl_keluar'];
$jumlah = $_POST['jumlah'];
$barang_id = $_POST['barang_id'];

$qInsertBarangKeluar = "insert into barangkeluar
                    values (NULL,
                    '$tgl_keluar',
                    '$jumlah',
                    '$barang_id')";

$myConn->query($qInsertBarangKeluar);

header("location:barangkeluar.php");