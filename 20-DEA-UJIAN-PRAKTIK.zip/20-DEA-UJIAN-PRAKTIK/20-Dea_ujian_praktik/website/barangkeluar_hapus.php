<?php 
include 'db_connect.php';
$id = $_GET['id'];

$qDellBarangKeluar="delete from barangkeluar where id='$id'";
$myConn->query($qDellBarangKeluar);

header("location:barangkeluar.php");