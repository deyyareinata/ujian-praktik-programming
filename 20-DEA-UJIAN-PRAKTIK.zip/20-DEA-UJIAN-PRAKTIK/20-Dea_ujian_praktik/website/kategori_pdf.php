<?php
	require_once("../dompdf/autoload.inc.php");
	use Dompdf\Dompdf;
	$demoPDF = new Dompdf();
	
	include "../db_connect.php";
	
	$qKategori = "SELECT * FROM kategori";
	$rsKategori = $myConn->query($qKategori);
	$data = "<center>
    <h4>LAPORAN KATEGORI</h4>
	<h5>Admin Inventory</h5>
  </center>";

	$data .= '<html>
	<head>
	<style>
	table, td, th {
  		border: 2px solid black;
		}

	table {
	border-collapse: collapse;
	width: 100%;
	}

	th {
		text-align: center;
		}

	td {
	height: 10px;
	vertical-align: left;
	}
	</style>
	</head>
	<table>';
	
	$data .= "<thead>
	<tr>
	  <th>NO</th>
	  <th>KATEGORI</th>
	  <th>KETERANGAN</th>
	</tr>
  </thead>";

	while($row = $rsKategori->fetch_assoc()){
		$data .= "<tr>";
			$data .= "<td>".$row['id']."</td>";
			$data .= "<td>".$row['kategori']."</td>";
			$data .= "<td>".$row['keterangan']."</td>";
		$data .= "</tr>";
	}
	$data .= "</table>";
	
	
	//data akan dibuat pdf
	$demoPDF->loadHtml($data);	
	$demoPDF->setPaper('A4', 'potrait');
	$demoPDF->render();
	
	//memastikan file pdf bisa dibuka di browser chrome
	ob_end_clean();
	$demoPDF->stream('kategori.pdf');
	//$demoPDF->stream('kategori.pdf',array("Attachment" => 0));

?>
</body>
</html>
