<?php 
include '../db_connect.php';
$id  = $_POST['id'];
$kategori = $_POST['kategori'];
$keterangan = $_POST['keterangan'];

$qInsertKategori = "insert into kategori
                    values (NULL,
                    '$id',
                    '$kategori',
                    '$keterangan')";

$myConn->query($qInsertKategori);
	


header("location:kategori.php");