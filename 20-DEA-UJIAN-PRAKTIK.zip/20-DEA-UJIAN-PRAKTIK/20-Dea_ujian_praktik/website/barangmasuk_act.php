<?php 
include 'db_connect.php';
$tgl_masuk = $_POST['tgl_masuk'];
$jumlah = $_POST['jumlah'];
$barang_id = $_POST['barang_id'];

$qInsertBarangMasuk = "insert into barangmasuk
                    values (NULL,
                    '$tgl_masuk',
                    '$jumlah',
                    '$barang_id')";

$myConn->query($qInsertBarangMasuk);

header("location:barangmasuk.php");