<?php
    $hostname = "localhost";
    $username = "admin_inventory";
    $password = "123";
    $database = "db_inventory";

    $myConn = new mysqli($hostname,$username,$password,$database);
    if($myConn->connect_errno){
        echo "Login Gagal";
        die("STOP");
    }

?>